@extends('dashboard.layouts.app')

@section('title', 'إضافة عقار جديد')

@section('content')
<div class="container-fluid">
    <h1 class="text-left">إضافة عقار جديد</h1>

    <!-- عرض الأخطاء -->
    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

    <form id="product-form" action="{{ route('products.store') }}" method="POST" enctype="multipart/form-data">
        @csrf

        <!-- القسم الأول: الحقول النصية -->
        <div class="card mb-4">
            <div class="card-header">بيانات العقار</div>
            <div class="card-body">
                <div class="form-group mb-3">
                    <label for="parent_city">المدينة:</label>
                    <select name="city_id" class="form-control" id="parent_city">
                        <option value="" disabled {{ old('city_id') ? '' : 'selected' }}>اختر المدينة</option>
                        @foreach ($mainCities as $city)
                            <option value="{{ $city->id }}" {{ old('city_id') == $city->id ? 'selected' : '' }}>
                                {{ $city->name }}
                            </option>
                        @endforeach
                    </select>
                </div>

                <div class="form-group mb-3">
                    <label for="neighborhood_id">الحي:</label>
                    <select name="neighborhood_id" class="form-control" id="sub_cities">
                        <option value="" disabled selected>اختر الحي</option>
                        @foreach ($subCities as $subCity)
                            <option value="{{ $subCity->id }}" {{ old('neighborhood_id') == $subCity->id ? 'selected' : '' }}>
                                {{ $subCity->name }}
                            </option>
                        @endforeach
                    </select>
                </div>

                <div class="form-group mb-3">
                    <label for="title">العنوان:</label>
                    <input type="text" name="title" id="title" class="form-control" value="{{ old('title') }}">
                </div>

                <div class="form-group mb-3">
                    <label for="description">الوصف:</label>
                    <textarea name="description" id="description" class="form-control" rows="4">{{ old('description') }}</textarea>
                </div>

                <div class="form-group mb-3">
                    <label for="price">السعر:</label>
                    <input type="number" name="price" id="price" class="form-control" step="0.01" value="{{ old('price') }}">
                </div>

                <div class="form-group mb-3">
                    <label for="monthly_installment">القسط الشهري:</label>
                    <input type="text" name="monthly_installment" id="monthly_installment" class="form-control" value="{{ old('monthly_installment') }}">
                </div>

                <div class="form-group mb-3">
                    <label for="ad_number">رقم الإعلان:</label>
                    <input type="number" name="ad_number" id="ad_number" class="form-control" value="{{ old('ad_number') }}">
                </div>

                <div class="form-group mb-3">
                    <label for="property_usage">استخدام العقار:</label>
                    <select name="property_usage" id="property_usage" class="form-control">
                        <option value="" disabled {{ old('property_usage') ? '' : 'selected' }}>اختر نوع الاستخدام</option>
                        <option value="سكني" {{ old('property_usage') == 'سكني' ? 'selected' : '' }}>سكني</option>
                        <option value="تجاري" {{ old('property_usage') == 'تجاري' ? 'selected' : '' }}>تجاري</option>
                    </select>
                </div>

                <div class="form-group mb-3">
                    <label for="property_facade">واجهة العقار:</label>
                    <select name="property_facade" id="property_facade" class="form-control">
                        <option value="شرق" {{ old('property_facade') == 'شرق' ? 'selected' : '' }}>شرق</option>
                        <option value="غرب" {{ old('property_facade') == 'غرب' ? 'selected' : '' }}>غرب</option>
                        <option value="شمال" {{ old('property_facade') == 'شمال' ? 'selected' : '' }}>شمال</option>
                        <option value="جنوب" {{ old('property_facade') == 'جنوب' ? 'selected' : '' }}>جنوب</option>
                    </select>
                </div>

                <div class="form-group mb-3">
                    <label for="video">رابط فيديو (YouTube):</label>
                    <input type="text" name="video" id="video" class="form-control" value="{{ old('video') }}">
                </div>

                <div class="form-group mb-3">
                    <label for="location">الموقع:</label>
                    <input type="text" name="location" id="location" class="form-control" value="{{ old('location') }}">
                </div>

                <div class="form-group mb-3">
                    <label for="bedrooms">عدد الغرف:</label>
                    <input type="number" name="bedrooms" id="bedrooms" class="form-control" value="{{ old('bedrooms') }}">
                </div>

                <div class="form-group mb-3">
                    <label for="bathrooms">عدد الحمامات:</label>
                    <input type="number" name="bathrooms" id="bathrooms" class="form-control" value="{{ old('bathrooms') }}">
                </div>

                <div class="form-group mb-3">
                    <label for="area">المساحة (متر مربع):</label>
                    <input type="number" name="area" id="area" class="form-control" value="{{ old('area') }}">
                </div>
            </div>
        </div>
        
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">

        <div class="card mb-4">
            <div class="card-header">ميزات العقار</div>
            <div class="card-body">
                <div id="features-checkboxes" class="form-group mb-3">
                    <label>اختر الميزات:</label>
                    <div class="row">
                        @foreach (App\Models\Product::$featuresList as $feature => $icon)
                            <div class="col-md-3 mb-2">
                                <div class="form-check">
                                    <input type="checkbox" name="features[]" value="{{ $feature }}" id="feature_{{ $feature }}" class="form-check-input">
                                    <label class="form-check-label" for="feature_{{ $feature }}">
                                        <i class="{{ $icon }}"></i> {{ $feature }}
                                    </label>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>

                <!-- حقل مخفي لجمع الميزات المحددة -->
                <input type="hidden" name="features" id="features" value="{{ old('features') }}">
            </div>
        </div>

        <!-- القسم الثاني: رفع الملفات -->
        <div class="card mb-4">
            <div class="card-header">رفع الملفات</div>
            <div class="card-body">
                <div class="form-group mb-3">
                    <label for="image">الصورة الرئيسية:</label>
                    <input type="file" name="image" id="image" class="form-control" accept="image/*">
                    <div id="image-preview" class="mt-2"></div>
                </div>

                <div class="form-group mb-3">
                    <label for="images">صور إضافية:</label>
                    <input type="file" name="images[]" id="images" class="form-control" multiple accept="image/*">
                    <div id="images-preview" class="mt-2"></div>
                </div>

                <div class="form-group mb-3">
                    <label for="croquis">الكروكي:</label>
                    <input type="file" name="croquis" id="croquis" class="form-control" accept="image/*">
                    <div id="croquis-preview" class="mt-2"></div>
                </div>

                <div class="form-group mb-3">
                    <label for="profile_project">ملف تعريف المشروع:</label>
                    <input type="file" name="profile_project" id="profile_project" class="form-control">
                    <div id="profile-preview" class="mt-2"></div>
                </div>
            </div>
        </div>

        <!-- زر الحفظ مع عداد التحميل -->
        <div class="form-group mb-3 text-center">
            <button type="submit" id="submit-button" class="btn btn-primary">حفظ</button>
            <div id="loading-container" style="display: none; margin-top: 20px;">
                <progress id="form-upload-progress" value="0" max="100" style="width: 100%;"></progress>
                <p id="loading-percentage" style="font-weight: bold;">0%</p>
            </div>
        </div>
    </form>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        // جلب الأحياء عند تغيير المدينة
        document.getElementById('parent_city').addEventListener('change', function () {
            const cityId = this.value;
            fetch(`{{ url('/get-neighborhoods/') }}/${cityId}`)
                .then(response => response.json())
                .then(data => {
                    const neighborhoods = document.getElementById('sub_cities');
                    neighborhoods.innerHTML = '<option value="" disabled selected>اختر الحي</option>';
                    data.forEach(neighborhood => {
                        const option = document.createElement('option');
                        option.value = neighborhood.id;
                        option.textContent = neighborhood.name;
                        neighborhoods.appendChild(option);
                    });
                });
        });

        // معاينة الملفات
        function previewFiles(inputId, previewContainerId) {
            const input = document.getElementById(inputId);
            const previewContainer = document.getElementById(previewContainerId);

            input.addEventListener('change', function (event) {
                previewContainer.innerHTML = '';
                Array.from(event.target.files).forEach(file => {
                    const reader = new FileReader();
                    reader.onload = e => {
                        const img = document.createElement('img');
                        img.src = e.target.result;
                        img.style.width = '100px';
                        img.style.height = '100px';
                        img.style.objectFit = 'cover';
                        img.style.margin = '5px';
                        previewContainer.appendChild(img);
                    };
                    reader.readAsDataURL(file);
                });
            });
        }

        previewFiles('image', 'image-preview');
        previewFiles('images', 'images-preview');
        previewFiles('croquis', 'croquis-preview');
        previewFiles('profile_project', 'profile-preview');

        // عداد التحميل للنموذج
        const form = document.getElementById('product-form');
        const submitButton = document.getElementById('submit-button');
        const progressBar = document.getElementById('form-upload-progress');
        const loadingContainer = document.getElementById('loading-container');
        const loadingPercentage = document.getElementById('loading-percentage');

        form.addEventListener('submit', function (event) {
            event.preventDefault();

            const formData = new FormData(form);
            const xhr = new XMLHttpRequest();

            xhr.open('POST', form.action, true);
            xhr.setRequestHeader('X-CSRF-TOKEN', '{{ csrf_token() }}');

            xhr.upload.onprogress = function (event) {
                if (event.lengthComputable) {
                    const percentComplete = Math.round((event.loaded / event.total) * 100);
                    progressBar.value = percentComplete;
                    loadingPercentage.textContent = percentComplete + '%';
                    loadingContainer.style.display = 'block';
                }
            };

            xhr.onload = function () {
                if (xhr.status === 200) {
                    window.location.href = '{{ route('products.index') }}';
                } else {
                    alert('حدث خطأ أثناء الحفظ.');
                    loadingContainer.style.display = 'none';
                }
            };

            xhr.onerror = function () {
                alert('حدث خطأ في الاتصال بالسيرفر.');
                loadingContainer.style.display = 'none';
            };

            xhr.send(formData);
        });
    });
</script>
@endsection
