<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-12">
                <script>
                    document.write(new Date().getFullYear())
                </script> © Aqar.
            </div>
        </div>
    </div>
</footer>
